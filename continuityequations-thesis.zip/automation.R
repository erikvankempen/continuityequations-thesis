require("systemfit")
require("zoo")
require("vars")
require("tseries")
require("forecast")
library('xlsx')

counter <- 1

source('models.R')

while(TRUE) {
  source('test.R')
  source('report.R')
  source('utilities.R')
  cat('\nTest ran ', counter, ' times\n')
  counter <- counter + 1
}